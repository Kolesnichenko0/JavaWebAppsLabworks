package csit.semit.kde.hibernatejavawebappskdelab2.entity;

import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.io.Serial;
import java.time.Duration;
import java.time.LocalTime;

@Entity
@Table(name = "train", indexes = {
        @Index(name = "idx_train_departure_station", columnList = "departure_station"),
        @Index(name = "idx_train_arrival_station", columnList = "arrival_station"),
        @Index(name = "idx_train_departure_time", columnList = "departure_time")
})
@Getter @Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class Train extends Transport {

    @Serial
    private static final long serialVersionUID = 176873029745254541L;

    private static final String NUMBER_REGEX = "^[0-9]{3}[А-ЩЬЮЯЇІЄҐ]$";
    private static final String STATION_REGEX = "^([А-ЩЬЮЯЇІЄҐ][а-щА-ЩЬьЮюЯяЇїІіЄєҐ']*([ \\-][а-щА-ЩьЮюЯяЇїІіЄєҐ0-9'()]*)*){1,100}$";

    @NotNull
    @Pattern(regexp = NUMBER_REGEX, message = "Number must start with three digits, followed by one uppercase Ukrainian letter.")
    @Column(name = "number", nullable = false, unique = true, length = 4)
    private String number;

    @NotNull
    @Pattern(regexp = STATION_REGEX, message = "Station name must consist of Ukrainian letters and can include spaces and apostrophes, with a maximum length of 100 characters.")
    @Column(name = "departure_station", nullable = false, length = 100)
    private String departureStation;

    @NotNull
    @Pattern(regexp = STATION_REGEX, message = "Station name must consist of Ukrainian letters and can include spaces and apostrophes, with a maximum length of 100 characters.")
    @Column(name = "arrival_station", nullable = false, length = 100)
    private String arrivalStation;

    public Train(String number, String arrivalStation, String departureStation, MovementType movementType, LocalTime departureTime, Duration duration) {
        super(movementType, departureTime, duration);
        this.number = validateNumber(number);
        this.departureStation = validateStationName(departureStation);
        this.arrivalStation = validateStationName(arrivalStation);
    }

    public static String validateNumber(String number) {
        if (number == null || number.isEmpty()) {
            throw new IllegalArgumentException("The number cannot be empty");
        }

        number = number.trim();

        if (number.length() == 2) {
            number = "00" + number;
        } else if (number.length() == 3) {
            number = "0" + number;
        }

        String regex = "^[0-9]{3}[А-ЩЬЮЯЇІЄҐ]$";

        if (!number.matches(regex)) {
            throw new IllegalArgumentException("The number should consist of 1 to 3 digits and one Ukrainian letter");
        }

        return number;
    }

    public static String validateStationName(String station) {
        if (station == null || station.isEmpty()) {
            throw new IllegalArgumentException("Station name cannot be empty");
        }

        station = station.trim();

        if (Character.isLowerCase(station.charAt(0))) {
            station = Character.toUpperCase(station.charAt(0)) + station.substring(1);
        }

        String regex = "^([А-ЩЬЮЯЇІЄҐ][а-щА-ЩЬьЮюЯяЇїІіЄєҐ']*([ \\-][а-щА-ЩьЮюЯяЇїІіЄєҐ0-9'()]*)*){1,100}$";

        if (!station.matches(regex)) {
            throw new IllegalArgumentException("Station name must start with a Ukrainian capital letter and can include spaces, hyphens, numbers, and parentheses.");
        }

        return station;
    }

    public void setNumber(String number) {
        this.number = validateNumber(number);
    }

    public void setDepartureStation(String departureStation) {
        this.departureStation = validateStationName(departureStation);
    }

    public void setArrivalStation(String arrivalStation) {
        this.arrivalStation = validateStationName(arrivalStation);
    }
}

