package csit.semit.kde.hibernatejavawebappskdelab2.util.result.dao;

import csit.semit.kde.hibernatejavawebappskdelab2.enums.OperationStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.Result;
import lombok.Getter;
import lombok.ToString;

import java.util.List;
@ToString
public class OperationResult<E> implements Result<E, OperationStatus> {
    @Getter
    private final OperationStatus status;
    @Getter
    private E entity;
    @Getter
    private List<E> entityList;
    @Getter
    private String field;

    public OperationResult(OperationStatus status) {
        this.status = status;
    }

    public OperationResult(OperationStatus status, E entity, String field) {
        this.status = status;
        this.entity = entity;
        this.field = field;
    }

    public OperationResult(OperationStatus status, E entity) {
        this.status = status;
        this.entity = entity;
    }

    public OperationResult(OperationStatus status, List<E> entityList) {
        this.status = status;
        this.entityList = entityList;
    }
}

