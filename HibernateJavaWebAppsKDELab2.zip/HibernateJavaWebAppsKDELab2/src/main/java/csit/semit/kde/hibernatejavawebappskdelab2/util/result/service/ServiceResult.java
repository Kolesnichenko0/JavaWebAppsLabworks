package csit.semit.kde.hibernatejavawebappskdelab2.util.result.service;

import csit.semit.kde.hibernatejavawebappskdelab2.enums.OperationStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.ServiceStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.Result;
import lombok.Getter;
import lombok.ToString;

import java.util.List;
@ToString
public class ServiceResult<E> implements Result<E, ServiceStatus> {
    @Getter
    private final ServiceStatus status;
    @Getter
    private E entity;
    @Getter
    private List<E> entityList;
    @Getter
    private String field;

    public ServiceResult(ServiceStatus status) {
        this.status = status;
    }

    public ServiceResult(ServiceStatus status, E entity, String field) {
        this.status = status;
        this.entity = entity;
        this.field = field;
    }

    public ServiceResult(ServiceStatus status, E entity) {
        this.status = status;
        this.entity = entity;
    }

    public ServiceResult(ServiceStatus status, List<E> entityList) {
        this.status = status;
        this.entityList = entityList;
    }
}
