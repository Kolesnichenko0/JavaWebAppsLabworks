package csit.semit.kde.hibernatejavawebappskdelab2.dao;

import csit.semit.kde.hibernatejavawebappskdelab2.entity.SoftDeletable;
import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.OperationStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.dao.OperationResult;
import jakarta.persistence.criteria.*;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.lang.reflect.Field;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public interface ITrainDAO extends EntityDAO<Train> {
    default OperationResult<Train> findByKeySet(Train template, boolean includeDeleted) {
        if (includeDeleted) {
            return findByNumber(template.getNumber(), true);
        }
        return findByNumber(template.getNumber(), false);
    }

    default OperationResult<Train> findByNumber(String number, boolean includeDeleted) {
        try {
            Field numberField = getEntityClass().getDeclaredField("number");
            OperationResult<Train> result = findByKey(numberField, number, includeDeleted);

            System.out.println(result.getStatus());
            System.out.println(result.getEntity());
            if (result.getStatus() == OperationStatus.SUCCESS) {
                String fieldName = "number";
                return new OperationResult<>(OperationStatus.SUCCESS, result.getEntity(), fieldName);
            }
            return result;
        } catch (NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.FIELD_NOT_FOUND);
        }
    }

//    default OperationResult<Train> findByArrivalStation(String station) {
//        try {
//            station = Train.validateStationName(station);
//            return findByStationOrArrivalAndDeparture("arrivalStation", station, null, null, false);
//        } catch (IllegalArgumentException e) {
//            return new OperationResult<>(OperationStatus.VALIDATION_ERROR);
//        }
//    }
//
//    default OperationResult<Train> findByDepartureStation(String station) {
//        try {
//            station = Train.validateStationName(station);
//            return findByStationOrArrivalAndDeparture("departureStation", station,
//                    null, null, false);
//        } catch (IllegalArgumentException e) {
//            return new OperationResult<>(OperationStatus.VALIDATION_ERROR);
//        }
//    }
//    default OperationResult<Train> findByArrivalAndDeparture(String arrival, String departure) {
//        try {
//            arrival = Train.validateStationName(arrival);
//            departure = Train.validateStationName(departure);
//            return findByStationOrArrivalAndDeparture(null, null,
//                    arrival, departure, true);
//        } catch (IllegalArgumentException e) {
//            return new OperationResult<>(OperationStatus.VALIDATION_ERROR);
//        }
//    }

//    default OperationResult<Train> findByStationOrArrivalAndDeparture(String fieldName, String station,
//                                                                      String arrival, String departure, boolean combined) {
//        Transaction transaction = null;
//
//        try (Session session = getSessionFactory().openSession()) {
//            transaction = session.beginTransaction();
//
//            CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
//            CriteriaQuery<Train> criteriaQuery = criteriaBuilder.createQuery(getEntityClass());
//            Root<Train> root = criteriaQuery.from(getEntityClass());
//
//            List<Predicate> predicates = new ArrayList<>();
//
//            if (combined) {
//                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("arrivalStation")), "%" + arrival.toLowerCase() + "%"));
//                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("departureStation")), "%" + departure.toLowerCase() + "%"));
//            } else {
//                predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get(fieldName)), "%" + station.toLowerCase() + "%"));
//            }
//
//            if (SoftDeletable.class.isAssignableFrom(getEntityClass())) {
//                predicates.add(criteriaBuilder.isFalse(root.get("isDeleted")));
//            }
//
//            criteriaQuery.select(root).where(criteriaBuilder.and(predicates.toArray(new Predicate[0])));
//
//            List<Train> results = session.createQuery(criteriaQuery).getResultList();
//            transaction.commit();
//
//            if (results.isEmpty()) {
//                return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
//            } else {
//                return new OperationResult<>(OperationStatus.SUCCESS, results);
//            }
//        } catch (HibernateException e) {
//            rollbackTransaction(transaction);
//            e.printStackTrace();
//            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
//        } catch (Exception e) {
//            rollbackTransaction(transaction);
//            e.printStackTrace();
//            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
//        }
//    }

//    default OperationResult<Train> filterAndSortByCriteria(Set<MovementType> movementTypes, LocalTime from, LocalTime to,
//                                                    Duration minDuration, Duration maxDuration,
//                                                    Boolean sortByTrainNumberAsc, Boolean sortByDurationAsc,
//                                                    Boolean sortByDepartureTimeAsc) {
//        Transaction transaction = null;
//
//        try (Session session = getSessionFactory().openSession()) {
//            transaction = session.beginTransaction();
//
//            CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
//            CriteriaQuery<Train> criteriaQuery = criteriaBuilder.createQuery(getEntityClass());
//            Root<Train> root = criteriaQuery.from(getEntityClass());
//
//            List<Predicate> predicates = new ArrayList<>();
//
//            if (movementTypes != null && !movementTypes.isEmpty()) {
//                predicates.add(root.get("movementType").in(movementTypes));
//            }
//            if (from != null && to != null) {
//                predicates.add(criteriaBuilder.between(root.get("departureTime"), from, to));
//            }
//            if (minDuration != null && maxDuration != null) {
//                predicates.add(criteriaBuilder.between(root.get("duration"), minDuration, maxDuration));
//            }
//            if (SoftDeletable.class.isAssignableFrom(getEntityClass())) {
//                predicates.add(criteriaBuilder.isFalse(root.get("isDeleted")));
//            }
//
//            criteriaQuery.select(root).where(predicates.toArray(new Predicate[0]));
//
//            if (sortByTrainNumberAsc != null) {
//                criteriaQuery.orderBy(sortByTrainNumberAsc ? criteriaBuilder.asc(root.get("number")) : criteriaBuilder.desc(root.get("number")));
//            } else if (sortByDurationAsc != null) {
//                criteriaQuery.orderBy(sortByDurationAsc ? criteriaBuilder.asc(root.get("duration")) : criteriaBuilder.desc(root.get("duration")));
//            } else if (sortByDepartureTimeAsc != null) {
//                criteriaQuery.orderBy(sortByDepartureTimeAsc ? criteriaBuilder.asc(root.get("departureTime")) : criteriaBuilder.desc(root.get("departureTime")));
//            }
//
//            List<Train> results = session.createQuery(criteriaQuery).getResultList();
//
//            transaction.commit();
//            return new OperationResult<>(OperationStatus.SUCCESS, results);
//        } catch (HibernateException e) {
//            rollbackTransaction(transaction);
//            e.printStackTrace();
//            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
//        } catch (Exception e) {
//            rollbackTransaction(transaction);
//            e.printStackTrace();
//            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
//        }
//    }

    default OperationResult<Train> findAndFilterAndSortByCriteria(String number, String arrivalStation, String departureStation,
                                                           Set<MovementType> movementTypes, LocalTime from, LocalTime to,
                                                           Duration minDuration, Duration maxDuration,
                                                           Boolean sortByTrainNumberAsc, Boolean sortByDurationAsc,
                                                           Boolean sortByDepartureTimeAsc) {
        Transaction transaction = null;

        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
            CriteriaQuery<Train> criteriaQuery = criteriaBuilder.createQuery(getEntityClass());
            Root<Train> root = criteriaQuery.from(getEntityClass());

            List<Predicate> predicates = new ArrayList<>();

            if (number != null && !number.isEmpty()) {
                number = number.trim();
                predicates.add(criteriaBuilder.like(root.get("number"), "%" + number + "%"));
            } else {
                if (departureStation != null && !departureStation.isEmpty()) {
                    departureStation = departureStation.trim();
                    predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("departureStation")), "%" + departureStation.toLowerCase() + "%"));
                }
                if (arrivalStation != null && !arrivalStation.isEmpty()) {
                    arrivalStation = arrivalStation.trim();
                    predicates.add(criteriaBuilder.like(criteriaBuilder.lower(root.get("arrivalStation")), "%" + arrivalStation.toLowerCase() + "%"));
                }
            }

            if (movementTypes != null && !movementTypes.isEmpty()) {
                predicates.add(root.get("movementType").in(movementTypes));
            }
            if (from != null && to != null) {
                predicates.add(criteriaBuilder.between(root.get("departureTime"), from, to));
            }
            if (minDuration != null && maxDuration != null) {
                predicates.add(criteriaBuilder.between(root.get("duration"), minDuration, maxDuration));
            }
            if (SoftDeletable.class.isAssignableFrom(getEntityClass())) {
                predicates.add(criteriaBuilder.isFalse(root.get("isDeleted")));
            }

            criteriaQuery.select(root).where(predicates.toArray(new Predicate[0]));

            if (sortByTrainNumberAsc != null) {
                criteriaQuery.orderBy(sortByTrainNumberAsc ? criteriaBuilder.asc(root.get("number")) : criteriaBuilder.desc(root.get("number")));
            } else if (sortByDurationAsc != null) {
                criteriaQuery.orderBy(sortByDurationAsc ? criteriaBuilder.asc(root.get("duration")) : criteriaBuilder.desc(root.get("duration")));
            } else if (sortByDepartureTimeAsc != null) {
                criteriaQuery.orderBy(sortByDepartureTimeAsc ? criteriaBuilder.asc(root.get("departureTime")) : criteriaBuilder.desc(root.get("departureTime")));
            }

            List<Train> results = session.createQuery(criteriaQuery).getResultList();

            transaction.commit();
            if(results.isEmpty()) {
                return new OperationResult<>(OperationStatus.ENTITIES_NOT_FOUND);
            }
            return new OperationResult<>(OperationStatus.SUCCESS, results);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<Train> insertSampleTrains() {
        Transaction transaction = null;

        List<Train> trains = Arrays.asList(
                new Train("101К", "Київ-Пасажирський", "Львів", MovementType.DAILY, LocalTime.of(6, 45), Duration.ofSeconds(21420)),
                new Train("102А", "Одеса-Головна", "Дніпро-Головний", MovementType.EVEN_DAYS, LocalTime.of(14, 30), Duration.ofSeconds(37800)),
                new Train("203Б", "Львів", "Івано-Франківськ", MovementType.ODD_DAYS, LocalTime.of(10, 15), Duration.ofSeconds(10500)),
                new Train("304В", "Харків-Пасажирський", "Кривий Ріг-Головний", MovementType.DAILY, LocalTime.of(22, 10), Duration.ofSeconds(29400)),
                new Train("405Г", "Запоріжжя-1", "Одеса-Головна", MovementType.EVEN_DAYS, LocalTime.of(3, 20), Duration.ofSeconds(40800)),
                new Train("506Д", "Київ-Пасажирський", "Вінниця", MovementType.ODD_DAYS, LocalTime.of(18, 55), Duration.ofSeconds(14400)),
                new Train("607Е", "Миколаїв", "Дніпро-Головний", MovementType.DAILY, LocalTime.of(8, 40), Duration.ofSeconds(27000)),
                new Train("708Є", "Тернопіль", "Львів", MovementType.DAILY, LocalTime.of(11, 25), Duration.ofSeconds(7200)),
                new Train("809Ж", "Чернівці", "Одеса-Головна", MovementType.EVEN_DAYS, LocalTime.of(7, 0), Duration.ofSeconds(55800)),
                new Train("710З", "Хмельницький", "Київ-Пасажирський", MovementType.ODD_DAYS, LocalTime.of(19, 45), Duration.ofSeconds(25200)),
                new Train("102К", "Івано-Франківськ", "Житомир", MovementType.DAILY, LocalTime.of(5, 55), Duration.ofSeconds(33000)),
                new Train("112Л", "Полтава-Київська", "Чернівці", MovementType.EVEN_DAYS, LocalTime.of(9, 15), Duration.ofSeconds(46800)),
                new Train("123М", "Одеса-Головна", "Тернопіль", MovementType.ODD_DAYS, LocalTime.of(13, 35), Duration.ofSeconds(32400)),
                new Train("234Н", "Кривий Ріг-Головний", "Запоріжжя-1", MovementType.DAILY, LocalTime.of(16, 50), Duration.ofSeconds(18600)),
                new Train("345О", "Дніпро-Головний", "Миколаїв", MovementType.EVEN_DAYS, LocalTime.of(6, 5), Duration.ofSeconds(25800)),
                new Train("456П", "Львів", "Київ-Пасажирський", MovementType.DAILY, LocalTime.of(21, 30), Duration.ofSeconds(21600)),
                new Train("567Р", "Житомир", "Львів", MovementType.ODD_DAYS, LocalTime.of(11, 55), Duration.ofSeconds(50400)),
                new Train("678С", "Тернопіль", "Хмельницький", MovementType.EVEN_DAYS, LocalTime.of(15, 25), Duration.ofSeconds(14400)),
                new Train("789Т", "Київ-Пасажирський", "Одеса-Головна", MovementType.DAILY, LocalTime.of(23, 10), Duration.ofSeconds(36000)),
                new Train("590У", "Івано-Франківськ", "Запоріжжя-1", MovementType.DAILY, LocalTime.of(9, 5), Duration.ofSeconds(72000)),
                new Train("501Ф", "Львів", "Одеса-Головна", MovementType.ODD_DAYS, LocalTime.of(18, 20), Duration.ofSeconds(45000)),
                new Train("112Х", "Харків-Пасажирський", "Полтава-Київська", MovementType.EVEN_DAYS, LocalTime.of(12, 0), Duration.ofSeconds(10800)),
                new Train("223Ц", "Миколаїв", "Київ-Пасажирський", MovementType.DAILY, LocalTime.of(3, 45), Duration.ofSeconds(37800)),
                new Train("334Ч", "Тернопіль", "Дніпро-Головний", MovementType.EVEN_DAYS, LocalTime.of(14, 55), Duration.ofSeconds(46800)),
                new Train("445Ш", "Чернівці", "Львів", MovementType.ODD_DAYS, LocalTime.of(22, 50), Duration.ofSeconds(12600)),
                new Train("556Щ", "Одеса-Головна", "Запоріжжя-1", MovementType.DAILY, LocalTime.of(7, 35), Duration.ofSeconds(39600)),
                new Train("667Ь", "Кривий Ріг-Головний", "Івано-Франківськ", MovementType.EVEN_DAYS, LocalTime.of(17, 40), Duration.ofSeconds(64800)),
                new Train("578Ю", "Дніпро-Головний", "Миколаїв", MovementType.DAILY, LocalTime.of(10, 30), Duration.ofSeconds(28800)),
                new Train("589Я", "Хмельницький", "Київ-Пасажирський", MovementType.ODD_DAYS, LocalTime.of(19, 15), Duration.ofSeconds(25200)),
                new Train("590Ґ", "Запоріжжя-1", "Львів", MovementType.EVEN_DAYS, LocalTime.of(4, 55), Duration.ofSeconds(75600))
        );

        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            List<Train> persistedTrains = new ArrayList<>();
            for (Train train : trains) {
                session.persist(train);
                persistedTrains.add(train);
            }
            transaction.commit();
            return new OperationResult<>(OperationStatus.SUCCESS, persistedTrains);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<Train> restoreByNumber(String number) {
        OperationResult<Train> findResult = findByNumber(number, true);
        if (findResult.getStatus() != OperationStatus.SUCCESS) {
            System.out.println(findResult.getStatus());
            return findResult;
        }

        Train train = findResult.getEntity();
        if (train == null) {
            return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
        }

        return restoreById(train.getId());
    }
}
