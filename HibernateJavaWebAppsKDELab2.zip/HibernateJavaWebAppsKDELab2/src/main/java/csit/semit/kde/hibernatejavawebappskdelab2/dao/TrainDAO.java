package csit.semit.kde.hibernatejavawebappskdelab2.dao;

import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;
import lombok.Getter;
import org.hibernate.SessionFactory;

import jakarta.validation.Validator;

public class TrainDAO implements ITrainDAO{
    @Getter
    private SessionFactory sessionFactory;

    @Getter
    private Validator validator;

    private static final Class<Train> ENTITY_CLASS = Train.class;

    @Override
    public Class<Train> getEntityClass() {
        return ENTITY_CLASS;
    }
    public TrainDAO(SessionFactory sessionFactory, Validator validator) {
        this.validator = validator;
        this.sessionFactory = sessionFactory;
    }
}
