package csit.semit.kde.hibernatejavawebappskdelab2.entity;

import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import csit.semit.kde.hibernatejavawebappskdelab2.util.converter.DurationConverter;
import csit.semit.kde.hibernatejavawebappskdelab2.util.converter.MovementTypeConverter;
import jakarta.persistence.*;
import lombok.*;

import jakarta.validation.constraints.NotNull;
import org.hibernate.annotations.ColumnDefault;

import java.io.Serial;
import java.io.Serializable;
import java.time.Duration;
import java.time.LocalTime;

@Getter @Setter
@MappedSuperclass
@NoArgsConstructor
@EqualsAndHashCode
@ToString
public abstract class Transport implements Serializable, SoftDeletable {

    @Serial
    private static final long serialVersionUID = 12345678987654321L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    @NotNull
    @Enumerated(EnumType.STRING)
    @Convert(converter = MovementTypeConverter.class)
    @Column(name = "movement_type", nullable = false)
    protected MovementType movementType;

    @NotNull
    @Column(name = "departure_time", nullable = false)
    protected LocalTime departureTime;

    @NotNull
    @Convert(converter = DurationConverter.class)
    @Column(name = "duration_in_seconds", nullable = false)
    protected Duration duration;

    @NotNull
    @Column(name = "is_deleted", nullable = false)
    @ColumnDefault("0")
    protected Boolean isDeleted;

    public Transport(MovementType movementType, LocalTime departureTime, Duration duration) {
        this.movementType = validateMovementType(movementType);
        this.departureTime = validateDepartureTime(departureTime);
        this.duration = validateDuration(duration);
        this.isDeleted = false;
    }

    public static MovementType validateMovementType(MovementType movementType) {
        if (movementType == null) {
            throw new IllegalArgumentException("Movement type cannot be null");
        }
        return movementType;
    }

    public static LocalTime validateDepartureTime(LocalTime departureTime) {
        if (departureTime == null) {
            throw new IllegalArgumentException("Departure time cannot be null");
        }
        return departureTime.withNano(0);
    }

    public static Duration validateDuration(Duration duration) {
        if (duration == null) {
            throw new IllegalArgumentException("Duration cannot be null");
        }
        return duration.withNanos(0);
    }

    public static Boolean validateIsDeleted(Boolean isDeleted) {
        if (isDeleted == null) {
            throw new IllegalArgumentException("IsDeleted flag cannot be null");
        }
        return isDeleted;
    }

    public void setMovementType(MovementType movementType) {
        this.movementType = validateMovementType(movementType);
    }

    public void setDepartureTime(LocalTime departureTime) {
        this.departureTime = validateDepartureTime(departureTime);
    }

    public void setDuration(Duration duration) {
        this.duration = validateDuration(duration);
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = validateIsDeleted(isDeleted);
    }
}
