package csit.semit.kde.hibernatejavawebappskdelab2.util.mapper;

import csit.semit.kde.hibernatejavawebappskdelab2.dto.TrainDTO;
import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;

public class TrainMapper {
    public static Train toEntity(TrainDTO trainDTO) {
        if (trainDTO == null) {
            return null;
        }

        Train train = new Train(
                trainDTO.getNumber(),
                trainDTO.getArrivalStation(),
                trainDTO.getDepartureStation(),
                trainDTO.getMovementType(),
                trainDTO.getDepartureTime(),
                trainDTO.getDuration()
        );

        if (trainDTO.getId() != null) {
            train.setId(trainDTO.getId());
        }

        return train;
    }

    public static TrainDTO toDTO(Train train) {
        if (train == null) {
            return null;
        }
        return new TrainDTO(
                train.getId(),
                train.getNumber(),
                train.getDepartureStation(),
                train.getArrivalStation(),
                train.getMovementType(),
                train.getDepartureTime(),
                train.getDuration()
        );
    }
}
