package csit.semit.kde.hibernatejavawebappskdelab2.entity;

public interface SoftDeletable {
    void setIsDeleted(Boolean isDeleted);
    Boolean getIsDeleted();
}
