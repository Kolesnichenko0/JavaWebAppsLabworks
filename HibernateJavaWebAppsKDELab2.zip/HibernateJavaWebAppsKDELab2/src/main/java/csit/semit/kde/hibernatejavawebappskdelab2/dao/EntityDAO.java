package csit.semit.kde.hibernatejavawebappskdelab2.dao;

import csit.semit.kde.hibernatejavawebappskdelab2.entity.SoftDeletable;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.OperationStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.dao.OperationResult;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.validation.ConstraintViolation;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import jakarta.validation.Validator;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Set;

public interface EntityDAO<E> {
    SessionFactory getSessionFactory();
    Validator getValidator();
    Class<E> getEntityClass();
    OperationResult<E> findByKeySet(E template, boolean includeDeleted);
    default void rollbackTransaction(Transaction transaction) {
        if (transaction != null && transaction.isActive()) {
            transaction.rollback();
        }
    }
    private OperationResult<E> validateEntity(E entity) {
        Validator validator = getValidator();
        Set<ConstraintViolation<E>> violations = validator.validate(entity);
        if (!violations.isEmpty()) {
            for (ConstraintViolation<E> violation : violations) {
                System.err.println(violation.getMessage());
            }
            return new OperationResult<>(OperationStatus.VALIDATION_ERROR);
        }
        return new OperationResult<>(OperationStatus.SUCCESS);
    }

    private OperationResult<E> checkDuplicateWithDeleted(E entity) {
        OperationResult<E> findResult = findByKeySet(entity, true);
        if (findResult.getStatus() == OperationStatus.SUCCESS) {
            return new OperationResult<>(OperationStatus.DUPLICATE_ENTRY, findResult.getEntity(), findResult.getField());
        } else if (findResult.getStatus() == OperationStatus.VALIDATION_ERROR) {
            return new OperationResult<>(OperationStatus.VALIDATION_ERROR);
        } else if (findResult.getStatus() == OperationStatus.DATABASE_ERROR) {
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        }
        return new OperationResult<>(OperationStatus.SUCCESS);
    }

    default OperationResult<E> getAllList(boolean includeDeleted) {
        Transaction transaction = null;

        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
            CriteriaQuery<E> criteriaQuery = criteriaBuilder.createQuery(getEntityClass());

            Root<E> root = criteriaQuery.from(getEntityClass());

            if (SoftDeletable.class.isAssignableFrom(getEntityClass())) {
                if (includeDeleted) {
                    criteriaQuery.select(root).where(criteriaBuilder.isTrue(root.get("isDeleted")));
                } else {
                    criteriaQuery.select(root).where(criteriaBuilder.isFalse(root.get("isDeleted")));
                }
            } else {
                criteriaQuery.select(root);
            }

            List<E> results = session.createQuery(criteriaQuery).getResultList();

            transaction.commit();

            if(results.isEmpty()) {
                return new OperationResult<>(OperationStatus.ENTITIES_NOT_FOUND);
            }

            return new OperationResult<>(OperationStatus.SUCCESS, results);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<E> findById(Long id) {
        Transaction transaction = null;

        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            E result = session.get(getEntityClass(), id);

            transaction.commit();
            if (result == null) {
                return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
            } else if (result instanceof SoftDeletable && ((SoftDeletable) result).getIsDeleted()) {
                return new OperationResult<>(OperationStatus.ENTITY_DELETED);
            } else {
                return new OperationResult<>(OperationStatus.SUCCESS, result);
            }
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<E> findByKey(Field field, Object value, boolean includeDeleted) {
        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
            CriteriaQuery<E> criteriaQuery = criteriaBuilder.createQuery(getEntityClass());
            Root<E> root = criteriaQuery.from(getEntityClass());

            if (!includeDeleted && SoftDeletable.class.isAssignableFrom(getEntityClass())) {
                criteriaQuery.select(root).where(
                        criteriaBuilder.and(
                                criteriaBuilder.equal(root.get(field.getName()), value),
                                criteriaBuilder.isFalse(root.get("isDeleted"))
                        )
                );
            } else {
                criteriaQuery.select(root).where(criteriaBuilder.equal(root.get(field.getName()), value));
            }

            E result = session.createQuery(criteriaQuery).uniqueResult();

            transaction.commit();

            if (result == null) {
                return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
            } else {
                return new OperationResult<>(OperationStatus.SUCCESS, result);
            }
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<E> insert(E entityToSave) {
        OperationResult<E> validationResult = validateEntity(entityToSave);
        if (validationResult.getStatus() != OperationStatus.SUCCESS) {
            return validationResult;
        }

        OperationResult<E> duplicateCheckResult = checkDuplicateWithDeleted(entityToSave);
        if (duplicateCheckResult.getStatus() != OperationStatus.SUCCESS) {
            return duplicateCheckResult;
        }

        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(entityToSave);
            transaction.commit();
            return new OperationResult<>(OperationStatus.SUCCESS, entityToSave);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }
    default OperationResult<E> update(Long id, E entityToUpdate) {
        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            OperationResult<E> validationResult = validateEntity(entityToUpdate);
            if (validationResult.getStatus() != OperationStatus.SUCCESS) {
                return validationResult;
            }

            transaction = session.beginTransaction();

            E existingEntity = session.get(getEntityClass(), id);

            if (existingEntity == null) {
                return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
            } else if (existingEntity instanceof SoftDeletable && ((SoftDeletable) existingEntity).getIsDeleted()) {
                return new OperationResult<>(OperationStatus.ENTITY_DELETED);
            }

            OperationResult<E> duplicateCheckResult = checkDuplicateWithDeleted(entityToUpdate);
            if (duplicateCheckResult.getStatus() == OperationStatus.DUPLICATE_ENTRY) {
                E duplicateEntity = duplicateCheckResult.getEntity();
                if (duplicateEntity != null && !duplicateEntity.equals(existingEntity)) {
                    return new OperationResult<>(OperationStatus.DUPLICATE_ENTRY);
                }
            } else if (duplicateCheckResult.getStatus() != OperationStatus.SUCCESS) {
                return duplicateCheckResult;
            }

            E mergedEntity = session.merge(entityToUpdate);

            transaction.commit();

            return new OperationResult<>(OperationStatus.SUCCESS, mergedEntity);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<E> delete(Long id) {
        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            E existingEntity = session.get(getEntityClass(), id);
            if (existingEntity == null) {
                return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
            } else if (existingEntity instanceof SoftDeletable && ((SoftDeletable) existingEntity).getIsDeleted()) {
                return new OperationResult<>(OperationStatus.ENTITY_DELETED);
            }

            if (existingEntity instanceof SoftDeletable) {
                ((SoftDeletable) existingEntity).setIsDeleted(true);
            }

            transaction.commit();
            return new OperationResult<>(OperationStatus.SUCCESS, existingEntity);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<E> restoreById(Long id) {
        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            E existingEntity = session.get(getEntityClass(), id);
            if (existingEntity == null || !(existingEntity instanceof SoftDeletable)) {
                return new OperationResult<>(OperationStatus.ENTITY_NOT_FOUND);
            }

            SoftDeletable softDeletableEntity = (SoftDeletable) existingEntity;
            if (!softDeletableEntity.getIsDeleted()) {
                return new OperationResult<>(OperationStatus.ENTITY_ALREADY_ACTIVE);
            }

            softDeletableEntity.setIsDeleted(false);
            transaction.commit();

            return new OperationResult<>(OperationStatus.SUCCESS, existingEntity);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }

    default OperationResult<E> truncateTable() {
        Transaction transaction = null;
        try (Session session = getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            String tableName = getEntityClass().getSimpleName().toLowerCase();
            session.createNativeQuery("TRUNCATE TABLE " + tableName).executeUpdate();
            transaction.commit();
            return new OperationResult<>(OperationStatus.SUCCESS);
        } catch (HibernateException e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.DATABASE_ERROR);
        } catch (Exception e) {
            rollbackTransaction(transaction);
            e.printStackTrace();
            return new OperationResult<>(OperationStatus.UNKNOWN_ERROR);
        }
    }
}