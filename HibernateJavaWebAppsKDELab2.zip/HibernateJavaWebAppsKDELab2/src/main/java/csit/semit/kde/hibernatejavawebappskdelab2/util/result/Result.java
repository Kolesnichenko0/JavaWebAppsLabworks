package csit.semit.kde.hibernatejavawebappskdelab2.util.result;

import java.util.List;

public interface Result<E, S> {
    S getStatus();
    E getEntity();
    List<E> getEntityList();
    String getField();
    default boolean hasEntity() {
        return getEntity() != null;
    }
    default boolean hasEntityList() {
        return getEntityList() != null && !getEntityList().isEmpty();
    }
}
