package csit.semit.kde.hibernatejavawebappskdelab2.service;

import csit.semit.kde.hibernatejavawebappskdelab2.dao.DAOManager;
import csit.semit.kde.hibernatejavawebappskdelab2.dao.TrainDAO;
import csit.semit.kde.hibernatejavawebappskdelab2.dto.TrainDTO;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.service.ServiceResult;
import lombok.Getter;

import java.util.List;

public class TrainService implements ITrainService{
    @Getter
    private TrainDAO trainDAO;
    public TrainService(DAOManager daoManager) {
        this.trainDAO = daoManager.getTrainDAO();
    }
}
