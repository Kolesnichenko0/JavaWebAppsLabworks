package csit.semit.kde.hibernatejavawebappskdelab2.service;

import csit.semit.kde.hibernatejavawebappskdelab2.dao.TrainDAO;
import csit.semit.kde.hibernatejavawebappskdelab2.dto.TrainDTO;
import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.OperationStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.ServiceStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.mapper.TrainMapper;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.dao.OperationResult;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.service.ServiceResult;

import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public interface ITrainService {
    TrainDAO getTrainDAO();

    private ServiceStatus convertToServiceStatus(OperationStatus operationStatus) {
        switch (operationStatus) {
            case VALIDATION_ERROR:
                return ServiceStatus.VALIDATION_ERROR;
            case DUPLICATE_ENTRY:
                return ServiceStatus.DUPLICATE_ENTRY;
            case DATABASE_ERROR:
                return ServiceStatus.DATABASE_ERROR;
            case ENTITY_NOT_FOUND:
                return ServiceStatus.ENTITY_NOT_FOUND;
            case ENTITIES_NOT_FOUND:
                return ServiceStatus.ENTITIES_NOT_FOUND;
            case UNKNOWN_ERROR:
                return ServiceStatus.UNKNOWN_ERROR;
            case FIELD_NOT_FOUND:
                return ServiceStatus.UNKNOWN_ERROR;
            case ENTITY_DELETED:
                return ServiceStatus.ENTITY_DELETED;
            case ENTITY_ALREADY_ACTIVE:
                return ServiceStatus.ENTITY_ALREADY_ACTIVE;
            default:
                return ServiceStatus.UNKNOWN_ERROR;
        }
    }

    private void validateId(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("ID cannot be null or less than or equal to zero");
        }
    }

    private ServiceResult<TrainDTO> convertToServiceResultWithList(OperationResult<Train> operationResult) {
        if (operationResult.getStatus() == OperationStatus.SUCCESS) {
            List<TrainDTO> trainDTOList = operationResult.getEntityList().stream()
                    .map(TrainMapper::toDTO)
                    .collect(Collectors.toList());
            return new ServiceResult<>(ServiceStatus.SUCCESS, trainDTOList);
        } else {
            return new ServiceResult<>(convertToServiceStatus(operationResult.getStatus()));
        }
    }

    private ServiceResult<TrainDTO> convertToServiceResult(OperationResult<Train> operationResult) {
        if (operationResult.getStatus() == OperationStatus.SUCCESS) {
            return new ServiceResult<>(ServiceStatus.SUCCESS, TrainMapper.toDTO(operationResult.getEntity()));
        } else {
            return new ServiceResult<>(convertToServiceStatus(operationResult.getStatus()));
        }
    }

    private ServiceResult<TrainDTO> convertToServiceResultForDeleteUpdate(OperationResult<Train> operationResult) {
        if (operationResult.getStatus() == OperationStatus.DUPLICATE_ENTRY) {
            return new ServiceResult<>(ServiceStatus.DUPLICATE_ENTRY,
                    TrainMapper.toDTO(operationResult.getEntity()), operationResult.getField());
        } else if (operationResult.getStatus() == OperationStatus.SUCCESS) {
            return new ServiceResult<>(ServiceStatus.SUCCESS, TrainMapper.toDTO(operationResult.getEntity()));
        } else {
            return new ServiceResult<>(convertToServiceStatus(operationResult.getStatus()));
        }
    }

    default ServiceResult<TrainDTO> getAllList() {
        return convertToServiceResultWithList(getTrainDAO().getAllList(false));
    }

    default ServiceResult<TrainDTO> create(TrainDTO trainDTO) {
        Train train;
        try {
            train = TrainMapper.toEntity(trainDTO);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }

        if (train == null) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }

        OperationResult<Train> operationResult = getTrainDAO().insert(train);

        return convertToServiceResultForDeleteUpdate(operationResult);
    }

    default ServiceResult<TrainDTO> update(Long id, TrainDTO trainDTO) {
        Train train;
        try {
            train = TrainMapper.toEntity(trainDTO);
            validateId(id);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }

        if (train == null) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }

        OperationResult<Train> operationResult = getTrainDAO().update(id, train);

        return convertToServiceResultForDeleteUpdate(operationResult);
    }

    default ServiceResult<TrainDTO> delete(Long id) {
        try {
            validateId(id);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }

        OperationResult<Train> operationResult = getTrainDAO().delete(id);
        return convertToServiceResult(operationResult);
    }

    default ServiceResult<TrainDTO> restore(Long id) {
        try {
            validateId(id);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }
        OperationResult<Train> operationResult = getTrainDAO().restoreById(id);
        return convertToServiceResult(operationResult);
    }

    default ServiceResult<TrainDTO> restore(String number) {
        try {
            number = Train.validateNumber(number);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }
        OperationResult<Train> operationResult = getTrainDAO().restoreByNumber(number);
        return convertToServiceResult(operationResult);
    }

    default ServiceResult<TrainDTO> findById(Long id) {
        try {
            validateId(id);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }
        OperationResult<Train> operationResult = getTrainDAO().findById(id);
        return convertToServiceResult(operationResult);
    }

    default ServiceResult<TrainDTO> findByNumber(String number) {
        try {
            number = Train.validateNumber(number);
        } catch (IllegalArgumentException e) {
            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
        }
        OperationResult<Train> operationResult = getTrainDAO().findByNumber(number, false);
        return convertToServiceResult(operationResult);
    }

//    default ServiceResult<TrainDTO> findByArrivalStation(String arrivalStation) {
//        try {
//            arrivalStation = Train.validateStationName(arrivalStation);
//        } catch (IllegalArgumentException e) {
//            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
//        }
//        OperationResult<Train> operationResult = getTrainDAO().findByArrivalStation(arrivalStation);
//        return convertToServiceResultWithList(operationResult);
//    }
//
//    default ServiceResult<TrainDTO> findByDepartureStation(String departureStation) {
//        try {
//            departureStation = Train.validateStationName(departureStation);
//        } catch (IllegalArgumentException e) {
//            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
//        }
//        OperationResult<Train> operationResult = getTrainDAO().findByDepartureStation(departureStation);
//        return convertToServiceResultWithList(operationResult);
//    }
//
//    default ServiceResult<TrainDTO> findByArrivalAndDeparture(String arrivalStation, String departureStation) {
//        try {
//            arrivalStation = Train.validateStationName(arrivalStation);
//            departureStation = Train.validateStationName(departureStation);
//        } catch (IllegalArgumentException e) {
//            return new ServiceResult<>(ServiceStatus.VALIDATION_ERROR);
//        }
//        OperationResult<Train> operationResult = getTrainDAO().findByArrivalAndDeparture(arrivalStation, departureStation);
//        return convertToServiceResultWithList(operationResult);
//    }

    default ServiceResult<TrainDTO> findAndFilterAndSortByCriteria(String number, String arrivalStation, String departureStation,
                                                            Set<MovementType> movementTypes, LocalTime from, LocalTime to,
                                                            Duration minDuration, Duration maxDuration,
                                                            Boolean sortByNumberAsc, Boolean sortByDurationAsc,
                                                            Boolean sortByDepartureTimeAsc) {
        TrainDAO trainDAO = getTrainDAO();
        OperationResult<Train> operationResult = trainDAO.findAndFilterAndSortByCriteria(number, arrivalStation, departureStation,
                movementTypes, from, to, minDuration, maxDuration,
                sortByNumberAsc, sortByDurationAsc, sortByDepartureTimeAsc);

        return convertToServiceResultWithList(operationResult);
    }

//    default ServiceResult<TrainDTO> filterByMovementType(Set<MovementType> movementTypes) {
//        return filterAndSortByCriteria(movementTypes, null, null, null, null, null, null, null);
//    }
//
//    default ServiceResult<TrainDTO> filterByDepartureTimeRange(LocalTime from, LocalTime to) {
//        return filterAndSortByCriteria(null, from, to, null, null, null, null, null);
//    }
//
//    default ServiceResult<TrainDTO> filterByDurationRange(Duration minDuration, Duration maxDuration) {
//        return filterAndSortByCriteria(null, null, null, minDuration, maxDuration, null, null, null);
//    }
//
//    default ServiceResult<TrainDTO> sortByTrainNumberAsc() {
//        return filterAndSortByCriteria(null, null, null, null, null, true, null, null);
//    }
//
//    default ServiceResult<TrainDTO> sortByTrainNumberDesc() {
//        return filterAndSortByCriteria(null, null, null, null, null, false, null, null);
//    }
//
//    default ServiceResult<TrainDTO> sortByDurationAsc() {
//        return filterAndSortByCriteria(null, null, null, null, null, null, true, null);
//    }
//
//    default ServiceResult<TrainDTO> sortByDurationDesc() {
//        return filterAndSortByCriteria(null, null, null, null, null, null, false, null);
//    }
//
//    default ServiceResult<TrainDTO> sortByDepartureTimeAsc() {
//        return filterAndSortByCriteria(null, null, null, null, null, null, null, true);
//    }
//
//    default ServiceResult<TrainDTO> sortByDepartureTimeDesc() {
//        return filterAndSortByCriteria(null, null, null, null, null, null, null, false);
//    }
}
