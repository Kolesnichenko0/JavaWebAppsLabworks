package csit.semit.kde.hibernatejavawebappskdelab2.dao;

import org.hibernate.SessionFactory;

import jakarta.validation.Validator;

public class DAOManager {
    private TrainDAO trainDAO;

    public DAOManager(SessionFactory sessionFactory, Validator validator) {
        this.trainDAO = new TrainDAO(sessionFactory, validator);
    }

    public TrainDAO getTrainDAO() {
        return trainDAO;
    }
}
