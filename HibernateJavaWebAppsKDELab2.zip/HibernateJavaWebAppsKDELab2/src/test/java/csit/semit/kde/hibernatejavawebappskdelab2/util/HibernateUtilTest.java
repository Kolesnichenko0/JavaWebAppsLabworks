package csit.semit.kde.hibernatejavawebappskdelab2.util;

import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import csit.semit.kde.hibernatejavawebappskdelab2.util.hibernate.HibernateUtil;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class HibernateUtilTest {
    private static SessionFactory sessionFactory;

    /**
     * Initialize the SessionFactory before all tests.
     */
    @BeforeAll
    public static void setUp() {
        sessionFactory = HibernateUtil.getSessionFactory();
        assertNotNull(sessionFactory, "SessionFactory should be initialized and not null.");
    }

    /**
     * Test to verify that the session factory is working by opening and closing a session.
     */
    @Test
    @DisplayName("Test that Hibernate Session is created and opened successfully.")
    void testSessionCreation() {
        try (Session session = sessionFactory.openSession()) {
            assertTrue(session.isOpen(), "Session should be open.");
        } catch (Exception e) {
            fail("Opening session failed with exception: " + e.getMessage());
        }
    }

    @Test
    public void testSchemaCreation() {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        Train train = new Train("333А", "Київ", "Ха-Ав", MovementType.DAILY, LocalTime.MAX, Duration.ofSeconds(323432));
        Set<ConstraintViolation<Train>> violations = HibernateUtil.getValidator().validate(train);

        if (violations.isEmpty()) {
            session.persist(train);
            session.getTransaction().commit();
        } else {
            for (ConstraintViolation<Train> violation : violations) {
                System.out.println(violation.getMessage());
            }
            session.getTransaction().rollback();
        }
        session.close();
    }

    /**
     * Shutdown the SessionFactory after all tests.
     */
    @AfterAll
    public static void tearDown() {
        HibernateUtil.shutdown();
        assertFalse(sessionFactory.isOpen(), "SessionFactory should be closed.");
    }
}
