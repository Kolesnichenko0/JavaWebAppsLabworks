package csit.semit.kde.hibernatejavawebappskdelab2.dao;

import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.OperationStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.dao.OperationResult;
import csit.semit.kde.hibernatejavawebappskdelab2.util.hibernate.HibernateUtil;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class TrainDAOTest {

    private static TrainDAO trainDAO;

    @BeforeAll
    public static void setUp() {
        DAOManager daoManager = new DAOManager(HibernateUtil.getSessionFactory(), HibernateUtil.getValidator());
        assertNotNull(daoManager);
        trainDAO = daoManager.getTrainDAO();
    }

    @AfterAll
    public static void tearDown() {
        HibernateUtil.shutdown();
    }


    @Test
    public void testInsert_Success() {
        Train train = new Train("123А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        OperationResult<Train> result = trainDAO.insert(train);
        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("123А", result.getEntity().getNumber());
    }

    @Test
    public void testInsert_DuplicateEntry() {
        Train train = new Train("123А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        trainDAO.insert(train);

        OperationResult<Train> result = trainDAO.insert(train);
        assertEquals(OperationStatus.DUPLICATE_ENTRY, result.getStatus());
        assertNotNull(result.getField());
    }

    @Test
    public void testUpdate_Success() {
        Train train = new Train("124В", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(3));
        OperationResult<Train> insertResult = trainDAO.insert(train);
        Long id = insertResult.getEntity().getId();

        train.setDepartureStation("Одеса Головна");
        OperationResult<Train> updateResult = trainDAO.update(id, train);
        assertEquals(OperationStatus.SUCCESS, updateResult.getStatus());
        assertEquals("Одеса Головна", updateResult.getEntity().getDepartureStation());
    }

    @Test
    public void testUpdate_NonExistingEntity() {
        Train train = new Train("999М", "Миколаїв", "Київ", MovementType.DAILY, LocalTime.now(), Duration.ofHours(4));
        OperationResult<Train> result = trainDAO.update(999L, train);
        assertEquals(OperationStatus.ENTITY_NOT_FOUND, result.getStatus());
    }

    @Test
    public void testDelete_Success() {
        Train train = new Train("125А", "Київ", "Полтава", MovementType.DAILY, LocalTime.now(), Duration.ofHours(2));
        OperationResult<Train> insertResult = trainDAO.insert(train);
        Long id = insertResult.getEntity().getId();

        OperationResult<Train> deleteResult = trainDAO.delete(id);
        assertEquals(OperationStatus.SUCCESS, deleteResult.getStatus());
    }

    @Test
    public void testDelete_NonExistingEntity() {
        OperationResult<Train> result = trainDAO.delete(999L);
        assertEquals(OperationStatus.ENTITY_NOT_FOUND, result.getStatus());
    }

    @Test
    public void testRestoreById_Success() {
        Train train = new Train("126Д", "Полтава", "Тернопіль", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
        OperationResult<Train> insertResult = trainDAO.insert(train);
        Long id = insertResult.getEntity().getId();

        trainDAO.delete(id);
        OperationResult<Train> restoreResult = trainDAO.restoreById(id);
        assertEquals(OperationStatus.SUCCESS, restoreResult.getStatus());

        Train restoredTrain = trainDAO.findById(id).getEntity();
        assertFalse(restoredTrain.getIsDeleted());
    }

    @Test
    public void testRestoreById_AlreadyActiveEntity() {
        Train train = new Train("127Е", "Рівне", "Полтава", MovementType.DAILY, LocalTime.now(), Duration.ofHours(2));
        OperationResult<Train> insertResult = trainDAO.insert(train);
        Long id = insertResult.getEntity().getId();

        OperationResult<Train> restoreResult = trainDAO.restoreById(id);
        assertEquals(OperationStatus.ENTITY_ALREADY_ACTIVE, restoreResult.getStatus());
    }

    @Test
    public void testRestoreByNumber_Success() {
        Train train = new Train("207А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        OperationResult<Train> insertResult = trainDAO.insert(train);
        Long id = insertResult.getEntity().getId();
        trainDAO.delete(id);

        OperationResult<Train> restoreResult = trainDAO.restoreByNumber("207А");
        assertEquals(OperationStatus.SUCCESS, restoreResult.getStatus());

        Train restoredTrain = trainDAO.findById(id).getEntity();
        assertFalse(restoredTrain.getIsDeleted());
    }

    @Test
    public void testRestoreTrainByNumber_EntityNotFound() {
        OperationResult<Train> restoreResult = trainDAO.restoreByNumber("991М");
        assertEquals(OperationStatus.ENTITY_NOT_FOUND, restoreResult.getStatus());
    }

    @Test
    public void testFindByNumber_IncludeDeletedFalse() {
        Train train = new Train("128А", "Біла церква", "Київ", MovementType.ODD_DAYS, LocalTime.now(), Duration.ofHours(4));
        trainDAO.insert(train);
        Long id = train.getId();

        trainDAO.delete(id);

        OperationResult<Train> result = trainDAO.findByNumber("128А", false);
        assertNull(result.getEntity());
    }

    @Test
    public void testFindByNumber_IncludeDeletedTrue() {
        Train train = new Train("129А", "Івано-Франківськ", "Рівне", MovementType.EVEN_DAYS, LocalTime.now(), Duration.ofHours(3));
        trainDAO.insert(train);
        Long id = train.getId();

        trainDAO.delete(id);

        OperationResult<Train> result = trainDAO.findByNumber("129А", true);
        assertNotNull(result.getEntity());
    }

    @Test
    public void testFindByKeySet_ValidTemplate() {
        Train train = new Train("130А", "Київ", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(2));
        trainDAO.insert(train);

        Train template = new Train();
        template.setNumber("130А");

        OperationResult<Train> result = trainDAO.findByKeySet(template, false);
        Train resultEntity = result.getEntity();

        assertEquals("130А", resultEntity.getNumber());
    }

    @Test
    public void testFindById_Success() {
        Train train = new Train("131А", "Одеса", "Суми", MovementType.DAILY, LocalTime.now(), Duration.ofHours(2));
        OperationResult<Train> insertResult = trainDAO.insert(train);
        Long id = insertResult.getEntity().getId();

        OperationResult<Train> findResult = trainDAO.findById(id);
        assertEquals(OperationStatus.SUCCESS, findResult.getStatus());
        assertNotNull(findResult.getEntity());
        assertEquals("131А", findResult.getEntity().getNumber());
    }

    @Test
    public void testFindById_NonExistingEntity() {
        OperationResult<Train> findResult = trainDAO.findById(999L);
        assertEquals(OperationStatus.ENTITY_NOT_FOUND, findResult.getStatus());
    }

    @Test
    public void testGetAllList() {
        Train train1 = new Train("132А", "Полтава", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        trainDAO.insert(train1);

        Train train2 = new Train("133А", "Тернопіль", "Полтава", MovementType.EVEN_DAYS, LocalTime.now(), Duration.ofHours(2));
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.getAllList(false);
        assertTrue(result.getEntityList().size() >= 2);
    }

    @Test
    public void testFindByArrivalStation_Success() {
        Train train = new Train("134А", "Кииїв-Волинський", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        trainDAO.insert(train);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, "Кииїв-В",null,  null, null, null, null, null, null, null, null);
        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("Кииїв-Волинський", result.getEntityList().get(0).getArrivalStation());
    }

    @Test
    public void testFindByArrivalStation_NotFound() {
        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null,  "Неіснуюча станція", null,null, null, null, null, null, null, null, null);
        assertEquals(OperationStatus.ENTITIES_NOT_FOUND, result.getStatus());
    }

    @Test
    public void testFindByDepartureStation_Success() {
        Train train = new Train("135А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        trainDAO.insert(train);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null,"Львів", null, null, null, null, null, null, null, null);
        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("Львів", result.getEntityList().get(0).getDepartureStation());
    }

    @Test
    public void testFindByDepartureStation_NotFound() {
        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null,"Неіснуюча станція", null, null, null, null, null, null, null, null);
        assertEquals(OperationStatus.ENTITIES_NOT_FOUND, result.getStatus());
    }

    @Test
    public void testFindByArrivalAndDeparture_Success() {
        Train train = new Train("245А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        trainDAO.insert(train);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, "Київ", "Львів", null, null, null, null, null, null, null, null);
        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("Київ", result.getEntityList().get(0).getArrivalStation());
        assertEquals("Львів", result.getEntityList().get(0).getDepartureStation());
    }

    @Test
    public void testFindByArrivalAndDeparture_NotFound() {
        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, "Київ", "Неіснуюча станція", null, null, null, null, null, null, null, null);
        assertEquals(OperationStatus.ENTITIES_NOT_FOUND, result.getStatus());
    }

    @Test
    public void testFilterByMovementType() {
        Train train1 = new Train("137А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        Train train2 = new Train("138А", "Одеса", "Харків", MovementType.EVEN_DAYS, LocalTime.now(), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        Set<MovementType> movementTypes = Set.of(MovementType.DAILY);
        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, movementTypes, null, null, null, null, null, null, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertTrue(result.getEntityList().size() >= 1);
    }

    @Test
    public void testFilterByDepartureTimeRange() {
        Train train1 = new Train("139А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(7, 21), Duration.ofHours(5));
        Train train2 = new Train("140А", "Одеса", "Харків", MovementType.DAILY, LocalTime.of(7, 26), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        LocalTime from = LocalTime.of(7, 21);
        LocalTime to = LocalTime.of(7, 25);
        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, from, to, null, null, null, null, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals(1, result.getEntityList().size());
        assertEquals("139А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testFilterByDurationRange() {
        Train train1 = new Train("141А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(21));
        Train train2 = new Train("142А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(23));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        Duration minDuration = Duration.ofHours(21);
        Duration maxDuration = Duration.ofHours(22);
        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, minDuration, maxDuration, null, null, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals(1, result.getEntityList().size());
        assertEquals("141А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testSortByTrainNumberAsc() {
        Train train1 = new Train("001А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        Train train2 = new Train("144А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, null, null, true, null, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("001А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testSortByTrainNumberDesc() {
        Train train1 = new Train("145А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        Train train2 = new Train("298А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, null, null, false, null, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("298А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testSortByDurationAsc() {
        Train train1 = new Train("147А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(1));
        Train train2 = new Train("148А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, null, null, null, true, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("147А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testSortByDurationDesc() {
        Train train1 = new Train("149А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
        Train train2 = new Train("150А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(70));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, null, null, null, false, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("150А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testSortByDepartureTimeAsc() {
        Train train1 = new Train("151А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(0, 0), Duration.ofHours(5));
        Train train2 = new Train("152А", "Одеса", "Харків", MovementType.DAILY, LocalTime.of(12, 0), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, null, null, null, null, true);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("151А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testSortByDepartureTimeDesc() {
        Train train1 = new Train("153А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        Train train2 = new Train("154А", "Одеса", "Харків", MovementType.DAILY, LocalTime.of(23, 59), Duration.ofHours(6));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, null, null, null, null, null, null, null, false);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals("154А", result.getEntityList().get(0).getNumber());
    }

    @Test
    public void testFilterAndSortByMultipleCriteria() {
        Train train1 = new Train("155А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(22, 55), Duration.ofHours(32));
        Train train2 = new Train("156А", "Одеса", "Харків", MovementType.EVEN_DAYS, LocalTime.of(23, 0), Duration.ofHours(38));
        trainDAO.insert(train1);
        trainDAO.insert(train2);

        Set<MovementType> movementTypes = Set.of(MovementType.DAILY);
        LocalTime from = LocalTime.of(22, 54);
        LocalTime to = LocalTime.of(22, 56);
        Duration minDuration = Duration.ofHours(31);
        Duration maxDuration = Duration.ofHours(36);

        OperationResult<Train> result = trainDAO.findAndFilterAndSortByCriteria(null, null, null, movementTypes, from, to, minDuration, maxDuration, true, null, null);

        assertEquals(OperationStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntityList());
        assertFalse(result.getEntityList().isEmpty());
        assertEquals(1, result.getEntityList().size());
        assertEquals("155А", result.getEntityList().get(0).getNumber());
    }

//    @Test
//    public void testFindByArrivalStation_Success() {
//        Train train = new Train("134А", "Київ-Волинський", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        trainDAO.insert(train);
//
//        OperationResult<Train> result = trainDAO.findByArrivalStation("Київ-В");
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("Київ-Волинський", result.getEntityList().get(0).getArrivalStation());
//    }
//
//    @Test
//    public void testFindByArrivalStation_NotFound() {
//        OperationResult<Train> result = trainDAO.findByArrivalStation("Неіснуюча станція");
//        assertEquals(OperationStatus.ENTITY_NOT_FOUND, result.getStatus());
//    }
//
//    @Test
//    public void testFindByDepartureStation_Success() {
//        Train train = new Train("135А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        trainDAO.insert(train);
//
//        OperationResult<Train> result = trainDAO.findByDepartureStation("Львів");
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("Львів", result.getEntityList().get(0).getDepartureStation());
//    }
//
//    @Test
//    public void testFindByDepartureStation_NotFound() {
//        OperationResult<Train> result = trainDAO.findByDepartureStation("Неіснуюча станція");
//        assertEquals(OperationStatus.ENTITY_NOT_FOUND, result.getStatus());
//    }
//
//    @Test
//    public void testFindByArrivalAndDeparture_Success() {
//        Train train = new Train("136А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        trainDAO.insert(train);
//
//        OperationResult<Train> result = trainDAO.findByArrivalAndDeparture("Київ", "Львів");
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("Київ", result.getEntityList().get(0).getArrivalStation());
//        assertEquals("Львів", result.getEntityList().get(0).getDepartureStation());
//    }
//
//    @Test
//    public void testFindByArrivalAndDeparture_NotFound() {
//        OperationResult<Train> result = trainDAO.findByArrivalAndDeparture("Київ", "Неіснуюча станція");
//        assertEquals(OperationStatus.ENTITY_NOT_FOUND, result.getStatus());
//    }
//
//    @Test
//    public void testFilterByMovementType() {
//        Train train1 = new Train("137А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        Train train2 = new Train("138А", "Одеса", "Харків", MovementType.EVEN_DAYS, LocalTime.now(), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        Set<MovementType> movementTypes = Set.of(MovementType.DAILY);
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(movementTypes, null, null, null, null, null, null, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertTrue(result.getEntityList().size() >= 1);
//    }
//
//    @Test
//    public void testFilterByDepartureTimeRange() {
//        Train train1 = new Train("139А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(23, 51), Duration.ofHours(5));
//        Train train2 = new Train("140А", "Одеса", "Харків", MovementType.DAILY, LocalTime.of(23, 56), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        LocalTime from = LocalTime.of(23, 50);
//        LocalTime to = LocalTime.of(23, 55);
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, from, to, null, null, null, null, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals(1, result.getEntityList().size());
//        assertEquals("139А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testFilterByDurationRange() {
//        Train train1 = new Train("141А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(21));
//        Train train2 = new Train("142А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(23));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        Duration minDuration = Duration.ofHours(21);
//        Duration maxDuration = Duration.ofHours(22);
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, minDuration, maxDuration, null, null, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals(1, result.getEntityList().size());
//        assertEquals("141А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testSortByTrainNumberAsc() {
//        Train train1 = new Train("001А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        Train train2 = new Train("144А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, null, null, true, null, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("001А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testSortByTrainNumberDesc() {
//        Train train1 = new Train("145А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        Train train2 = new Train("208А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, null, null, false, null, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("208А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testSortByDurationAsc() {
//        Train train1 = new Train("147А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(1));
//        Train train2 = new Train("148А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, null, null, null, true, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("147А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testSortByDurationDesc() {
//        Train train1 = new Train("149А", "Київ", "Львів", MovementType.DAILY, LocalTime.now(), Duration.ofHours(5));
//        Train train2 = new Train("150А", "Одеса", "Харків", MovementType.DAILY, LocalTime.now(), Duration.ofHours(70));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, null, null, null, false, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("150А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testSortByDepartureTimeAsc() {
//        Train train1 = new Train("151А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(0, 0), Duration.ofHours(5));
//        Train train2 = new Train("152А", "Одеса", "Харків", MovementType.DAILY, LocalTime.of(12, 0), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, null, null, null, null, true);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("151А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testSortByDepartureTimeDesc() {
//        Train train1 = new Train("153А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
//        Train train2 = new Train("154А", "Одеса", "Харків", MovementType.DAILY, LocalTime.of(23, 59), Duration.ofHours(6));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(null, null, null, null, null, null, null, false);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals("154А", result.getEntityList().get(0).getNumber());
//    }
//
//    @Test
//    public void testFilterAndSortByMultipleCriteria() {
//        Train train1 = new Train("155А", "Київ", "Львів", MovementType.DAILY, LocalTime.of(22, 55), Duration.ofHours(32));
//        Train train2 = new Train("156А", "Одеса", "Харків", MovementType.EVEN_DAYS, LocalTime.of(23, 0), Duration.ofHours(38));
//        trainDAO.insert(train1);
//        trainDAO.insert(train2);
//
//        Set<MovementType> movementTypes = Set.of(MovementType.DAILY);
//        LocalTime from = LocalTime.of(22, 54);
//        LocalTime to = LocalTime.of(22, 56);
//        Duration minDuration = Duration.ofHours(31);
//        Duration maxDuration = Duration.ofHours(36);
//
//        OperationResult<Train> result = trainDAO.filterAndSortByCriteria(movementTypes, from, to, minDuration, maxDuration, true, null, null);
//
//        assertEquals(OperationStatus.SUCCESS, result.getStatus());
//        assertNotNull(result.getEntityList());
//        assertFalse(result.getEntityList().isEmpty());
//        assertEquals(1, result.getEntityList().size());
//        assertEquals("155А", result.getEntityList().get(0).getNumber());
//    }
}
