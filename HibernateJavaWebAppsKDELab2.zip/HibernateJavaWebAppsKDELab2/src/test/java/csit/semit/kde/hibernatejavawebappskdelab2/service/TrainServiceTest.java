package csit.semit.kde.hibernatejavawebappskdelab2.service;

import csit.semit.kde.hibernatejavawebappskdelab2.dao.DAOManager;
import csit.semit.kde.hibernatejavawebappskdelab2.dao.TrainDAO;
import csit.semit.kde.hibernatejavawebappskdelab2.dto.TrainDTO;
import csit.semit.kde.hibernatejavawebappskdelab2.entity.Train;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.MovementType;
import csit.semit.kde.hibernatejavawebappskdelab2.enums.ServiceStatus;
import csit.semit.kde.hibernatejavawebappskdelab2.util.hibernate.HibernateUtil;
import csit.semit.kde.hibernatejavawebappskdelab2.util.result.service.ServiceResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class TrainServiceTest {

    private TrainService trainService;

    @BeforeEach
    public void setUp() {
        DAOManager daoManager = new DAOManager(HibernateUtil.getSessionFactory(), HibernateUtil.getValidator());
        trainService = new TrainService(daoManager);
    }

    @Test
    public void testCreateTrain() {
        TrainDTO trainDTO = new TrainDTO(null, "123А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> result = trainService.create(trainDTO);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("123А", result.getEntity().getNumber());
    }

    @Test
    public void testCreateTrainDuplicate() {
        TrainDTO trainDTO = new TrainDTO(null, "130А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        trainService.create(trainDTO);
        ServiceResult<TrainDTO> result = trainService.create(trainDTO);

        assertEquals(ServiceStatus.DUPLICATE_ENTRY, result.getStatus());
    }

    @Test
    public void testFindById() {
        TrainDTO trainDTO = new TrainDTO(null, "124А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> createResult = trainService.create(trainDTO);
        Long id = createResult.getEntity().getId();

        ServiceResult<TrainDTO> result = trainService.findById(id);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("124А", result.getEntity().getNumber());
    }

    @Test
    public void testFindByIdInvalid() {
        ServiceResult<TrainDTO> result = trainService.findById(-1L);

        assertEquals(ServiceStatus.VALIDATION_ERROR, result.getStatus());
    }

    @Test
    public void testUpdateTrain() {
        TrainDTO trainDTO = new TrainDTO(null, "125Б", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> createResult = trainService.create(trainDTO);
        Long id = createResult.getEntity().getId();

        TrainDTO updatedTrainDTO = new TrainDTO(id, "125В", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> result = trainService.update(id, updatedTrainDTO);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("125В", result.getEntity().getNumber());
    }

    @Test
    public void testUpdateTrainDuplicate() {
        TrainDTO trainDTO1 = new TrainDTO(null, "126А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        TrainDTO trainDTO2 = new TrainDTO(null, "127А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        trainService.create(trainDTO1);
        ServiceResult<TrainDTO> createResult = trainService.create(trainDTO2);
        Long id = createResult.getEntity().getId();

        TrainDTO updatedTrainDTO = new TrainDTO(id, "126А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> result = trainService.update(id, updatedTrainDTO);

        assertEquals(ServiceStatus.DUPLICATE_ENTRY, result.getStatus());
    }

    @Test
    public void testDeleteTrain() {
        TrainDTO trainDTO = new TrainDTO(null, "120А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> createResult = trainService.create(trainDTO);
        Long id = createResult.getEntity().getId();

        ServiceResult<TrainDTO> result = trainService.delete(id);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("120А", result.getEntity().getNumber());
    }

    @Test
    public void testDeleteTrainInvalid() {
        ServiceResult<TrainDTO> result = trainService.delete(-1L);

        assertEquals(ServiceStatus.VALIDATION_ERROR, result.getStatus());
    }

    @Test
    public void testRestoreTrain() {
        TrainDTO trainDTO = new TrainDTO(null, "119А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> createResult = trainService.create(trainDTO);
        Long id = createResult.getEntity().getId();

        trainService.delete(id);
        ServiceResult<TrainDTO> result = trainService.restore(id);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("119А", result.getEntity().getNumber());
    }

    @Test
    public void testRestoreTrainInvalid() {
        ServiceResult<TrainDTO> result = trainService.restore(-1L);

        assertEquals(ServiceStatus.VALIDATION_ERROR, result.getStatus());
    }

    @Test
    public void testRestoreTrainByNumber() {
        TrainDTO trainDTO = new TrainDTO(null, "118А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        ServiceResult<TrainDTO> serviceResult = trainService.create(trainDTO);
        trainService.delete(serviceResult.getEntity().getId());

        ServiceResult<TrainDTO> result = trainService.restore("118А");

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("118А", result.getEntity().getNumber());
    }

    @Test
    public void testGetAllList() {
        trainService.create(new TrainDTO(null, "128А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
        trainService.create(new TrainDTO(null, "129А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));

        ServiceResult<TrainDTO> result = trainService.getAllList();

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertTrue(result.getEntityList().size() >= 2);
    }

    @Test
    public void testFindByNumber() {
        TrainDTO trainDTO = new TrainDTO(null, "135А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5));
        trainService.create(trainDTO);

        ServiceResult<TrainDTO> result = trainService.findByNumber("135А");

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertNotNull(result.getEntity());
        assertEquals("135А", result.getEntity().getNumber());
    }

    @Test
    public void testFindByArrivalStation() {
        trainService.create(new TrainDTO(null, "131А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
        trainService.create(new TrainDTO(null, "132А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));

        ServiceResult<TrainDTO> result = trainService.findAndFilterAndSortByCriteria(null, "Одеса-Головна", null, null, null, null, null, null, null, null, null);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertTrue(result.getEntityList().size() >= 2);
    }

    @Test
    public void testFindByDepartureStation() {
        trainService.create(new TrainDTO(null, "133А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
        trainService.create(new TrainDTO(null, "134А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));

        ServiceResult<TrainDTO> result = trainService.findAndFilterAndSortByCriteria(null, null, "Львів", null, null, null, null, null, null, null, null);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertTrue(result.getEntityList().size() >= 2);
    }

    @Test
    public void testFindByArrivalAndDeparture() {
        trainService.create(new TrainDTO(null, "139А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
        trainService.create(new TrainDTO(null, "136А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));

        ServiceResult<TrainDTO> result = trainService.findAndFilterAndSortByCriteria(null, "Одеса-Головна", "Львів", null, null, null, null, null, null, null, null);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertTrue(result.getEntityList().size() >= 2);
    }

    @Test
    public void testFilterAndSortByCriteria() {
        trainService.create(new TrainDTO(null, "137А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
        trainService.create(new TrainDTO(null, "138А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));

        ServiceResult<TrainDTO> result = trainService.findAndFilterAndSortByCriteria(null, null, null, Set.of(MovementType.DAILY), LocalTime.of(9, 0), LocalTime.of(11, 0), Duration.ofHours(4), Duration.ofHours(6), true, null, null);

        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
        assertTrue(result.getEntityList().size() >= 2);
    }

//    @Test
//    public void testFindByArrivalStation() {
//        trainService.create(new TrainDTO(null, "131А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//        trainService.create(new TrainDTO(null, "132А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//
//        ServiceResult<TrainDTO> result = trainService.findByArrivalStation("Одеса-Головна");
//
//        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
//        assertTrue(result.getEntityList().size() >= 2);
//    }
//
//    @Test
//    public void testFindByDepartureStation() {
//        trainService.create(new TrainDTO(null, "133А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//        trainService.create(new TrainDTO(null, "134А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//
//        ServiceResult<TrainDTO> result = trainService.findByDepartureStation("Львів");
//
//        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
//        assertTrue(result.getEntityList().size() >= 2);
//    }
//
//    @Test
//    public void testFindByArrivalAndDeparture() {
//        trainService.create(new TrainDTO(null, "139А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//        trainService.create(new TrainDTO(null, "136А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//
//        ServiceResult<TrainDTO> result = trainService.findByArrivalAndDeparture("Одеса-Головна", "Львів");
//
//        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
//        assertTrue(result.getEntityList().size() >= 2);
//    }
//
//    @Test
//    public void testFilterAndSortByCriteria() {
//        trainService.create(new TrainDTO(null, "137А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//        trainService.create(new TrainDTO(null, "138А", "Львів", "Одеса-Головна", MovementType.DAILY, LocalTime.of(10, 0), Duration.ofHours(5)));
//
//        ServiceResult<TrainDTO> result = trainService.filterAndSortByCriteria(Set.of(MovementType.DAILY), LocalTime.of(9, 0), LocalTime.of(11, 0), Duration.ofHours(4), Duration.ofHours(6), true, null, null);
//
//        assertEquals(ServiceStatus.SUCCESS, result.getStatus());
//        assertTrue(result.getEntityList().size() >= 2);
//    }

}
